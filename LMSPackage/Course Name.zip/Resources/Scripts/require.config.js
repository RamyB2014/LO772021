﻿require.config({
    urlArgs: 't=637612593947670833'
});